package classblast.web

import grails.test.mixin.Mock
import spock.lang.Specification

@Mock(SessionFilterFilters)
class SessionFilterFiltersSpec extends Specification {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
    }
}
