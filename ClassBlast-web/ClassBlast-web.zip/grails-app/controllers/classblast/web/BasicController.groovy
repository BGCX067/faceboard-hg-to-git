package classblast.web

class BasicController {

	def loadCollectionsOfUser(User user){
		print :p
		//return user.groupList
	}
    def index() { }
}
