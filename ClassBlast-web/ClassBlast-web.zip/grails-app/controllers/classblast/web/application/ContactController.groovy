package classblast.web.application

class ContactController {

    def index() { 
		render(view:"/contact")
	}
	
}
