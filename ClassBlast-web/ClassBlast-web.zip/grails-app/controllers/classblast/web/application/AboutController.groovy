package classblast.web.application

class AboutController {

    def about() {
		render(view:"/about/about")
	}
}
