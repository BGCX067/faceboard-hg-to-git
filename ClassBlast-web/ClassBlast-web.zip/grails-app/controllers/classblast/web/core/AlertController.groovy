package classblast.web.core

class AlertController {

    def index() {
		render(view:'/user/alerts')
	}
}
