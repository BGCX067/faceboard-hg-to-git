package classblast.web.core

class PostController {

    def index() {
		render("/user/posts")
	}
}
