package classblast.web.core

class NoteController {

    def index() { }
}
