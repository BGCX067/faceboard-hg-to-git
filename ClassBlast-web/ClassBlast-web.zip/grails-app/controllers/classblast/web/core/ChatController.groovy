package classblast.web.core

class ChatController {

    def index() { }
}
