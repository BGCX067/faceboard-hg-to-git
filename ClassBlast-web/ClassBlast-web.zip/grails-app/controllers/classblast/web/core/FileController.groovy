package classblast.web.core

class FileController {

    def index() { }
}
