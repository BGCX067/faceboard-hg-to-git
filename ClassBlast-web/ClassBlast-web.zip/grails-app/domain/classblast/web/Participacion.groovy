package classblast.web

class Participacion {
	User userRelated
	Mesaredonda meetingRelated
	Date beginningDate 
	Date endingDate
	float grade
	String body
	String image1
	String image2
	String image3
    static constraints = {
    }
}
