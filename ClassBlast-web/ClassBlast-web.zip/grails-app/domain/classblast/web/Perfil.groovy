package classblast.web

class Perfil {
	String email
	String username
	String profileDescription
	Rol genericRol
	User profileOwner
    static constraints = {
    }
}
