package classblast.web

class Semestre {
	int year
	int period
    static constraints = {
    }
}
