package classblast.web

class Tema {
	String topicTitle
	Seccion sectionRelated
    static constraints = {
    }
}
