package classblast.web

class Mensaje {
	User ownerMessage
	Date dateMessage
	Conversacion conversation
    static constraints = {
    }
}
