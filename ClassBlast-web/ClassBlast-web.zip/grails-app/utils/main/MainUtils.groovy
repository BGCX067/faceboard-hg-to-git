package main

/**
 * Clase de utilidades para manejar todo los aspectos relacionados con la
 * vista principal de la aplicación
 * @author ClassBlastDevelop
 *
 */
class MainUtils {

	static main(args) {}
	
	def methodTest={"accediendo a la zona utils"}
}
